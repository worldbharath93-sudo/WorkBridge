import React from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { BriefcaseBusiness, Home, LogOut, MessageCircle, PlusCircle, Search, UserCircle } from "lucide-react";
import { useAuth } from "../App";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const out = () => { logout(); navigate("/login"); };

  return (
    <header className="nav">
      <Link className="brand" to="/">
        <span className="brand-mark"><BriefcaseBusiness size={21}/></span>
        <span>WorkBridge</span>
      </Link>

      <nav>
        <NavLink to="/"><Home size={17}/> Home</NavLink>
        <NavLink to="/jobs"><Search size={17}/> Find Jobs</NavLink>
        {user?.role === "business" && <NavLink to="/post-task"><PlusCircle size={17}/> Post a Task</NavLink>}
        <NavLink to="/profile"><UserCircle size={17}/> My Profile</NavLink>
        <NavLink to="/messages"><MessageCircle size={17}/> Messages</NavLink>
      </nav>

      <div className="nav-user">
        <span className="avatar">{user?.name?.charAt(0)?.toUpperCase()}</span>
        <span className="hide-mobile">{user?.name}</span>
        <button className="icon-btn" onClick={out} title="Logout"><LogOut size={18}/></button>
      </div>
    </header>
  );
}
