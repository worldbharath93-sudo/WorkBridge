import React from "react";
import { Link } from "react-router-dom";
import { Clock3, MapPin, Wallet } from "lucide-react";

export default function JobCard({ job }) {
  return (
    <article className="job-card">
      <div className="job-top">
        <div>
          <span className="category">{job.category}</span>
          <h3>{job.title}</h3>
        </div>
        <div className="job-icon"><Wallet size={19}/></div>
      </div>
      <p className="muted">{job.description}</p>
      <div className="chips">
        {job.skills?.slice(0, 4).map(s => <span key={s} className="chip">{s}</span>)}
      </div>
      <div className="job-meta">
        <span><Wallet size={15}/> ₹{job.budgetMin} – ₹{job.budgetMax}</span>
        <span><Clock3 size={15}/> {job.duration}</span>
        <span><MapPin size={15}/> {job.location}</span>
      </div>
      <Link className="btn primary small" to={`/jobs/${job._id}`}>View Details</Link>
    </article>
  );
}
