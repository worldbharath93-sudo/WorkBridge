import React, { useEffect, useState } from "react";
import { CheckCircle2, MapPin, Save, BriefcaseBusiness } from "lucide-react";
import { api } from "../api";
import { useAuth } from "../App";

export default function Profile() {
  const { user, setUser }=useAuth();
  const [form,setForm]=useState({name:"",location:"",bio:"",skills:"",availability:"Flexible"});
  const [apps,setApps]=useState([]);

  useEffect(()=>{
    setForm({name:user.name||"",location:user.location||"",bio:user.bio||"",skills:(user.skills||[]).join(", "),availability:user.availability||"Flexible"});
    if(user.role==="worker") api.applications().then(r=>setApps(r.applications));
  },[user]);

  const save=async()=>{
    const r=await api.updateMe({...form,skills:form.skills.split(",").map(x=>x.trim()).filter(Boolean)});
    setUser(r.user);
  };

  return <div className="page">
    <div className="profile-head card">
      <div className="profile-avatar">{user.name?.charAt(0)}</div>
      <div><h1>{user.name}</h1><p className="muted">{user.role==="worker"?"Student / Worker":"Small Business"} · <MapPin size={15}/> {user.location||"Location not added"}</p></div>
      <div className="profile-stat"><b>{user.completedTasks||0}</b><span>Completed tasks</span></div>
      <div className="profile-stat"><b>{user.verifiedSkills?.length||0}</b><span>Verified skills</span></div>
    </div>
    <div className="profile-layout">
      <section className="card form-card">
        <div className="section-head"><h2>Profile information</h2><button className="btn primary small" onClick={save}><Save size={16}/> Save</button></div>
        <label>Name</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <label>Location</label><input value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/>
        <label>Availability</label><select value={form.availability} onChange={e=>setForm({...form,availability:e.target.value})}><option>Flexible</option><option>Weekdays</option><option>Weekends</option></select>
        <label>Skills</label><input value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})}/>
        <label>About</label><textarea rows="5" value={form.bio} onChange={e=>setForm({...form,bio:e.target.value})}/>
      </section>
      <aside className="card">
        <h2>Skills</h2>
        <div className="chips">{(user.skills||[]).map(s=><span className="chip" key={s}>{s}</span>)}</div>
        <h2 className="mt">Verified</h2>
        {(user.verifiedSkills||[]).map(s=><div className="verified" key={s}><CheckCircle2 size={16}/> {s}</div>)}
      </aside>
    </div>
    {user.role==="worker" && <section><div className="section-head"><h2>My applications</h2></div><div className="job-grid">{apps.map(j=><div className="card" key={j._id}><BriefcaseBusiness/><h3>{j.title}</h3><span className="status">{j.applicationStatus}</span></div>)}</div></section>}
  </div>;
}
