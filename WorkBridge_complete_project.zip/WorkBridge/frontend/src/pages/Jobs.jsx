import React, { useEffect, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import { api } from "../api";
import JobCard from "../components/JobCard";

export default function Jobs() {
  const [jobs,setJobs]=useState([]);
  const [q,setQ]=useState("");
  const [location,setLocation]=useState("");
  const [category,setCategory]=useState("");

  const load = () => {
    const p = new URLSearchParams();
    if(q) p.set("q",q); if(location) p.set("location",location); if(category) p.set("category",category);
    api.jobs(`?${p.toString()}`).then(r=>setJobs(r.jobs)).catch(()=>setJobs([]));
  };
  useEffect(load, []);

  return (
    <div className="page">
      <div className="page-title"><div><p className="eyebrow">OPPORTUNITY BOARD</p><h1>Browse Jobs</h1><p className="muted">Find short-term work based on your skills, location and availability.</p></div></div>
      <div className="search-panel">
        <div className="searchbox"><Search size={18}/><input placeholder="Search jobs, tasks or skills..." value={q} onChange={e=>setQ(e.target.value)} /></div>
        <input placeholder="Location" value={location} onChange={e=>setLocation(e.target.value)} />
        <select value={category} onChange={e=>setCategory(e.target.value)}><option value="">All categories</option><option>Design</option><option>Development</option><option>Marketing</option><option>Admin</option></select>
        <button className="btn primary" onClick={load}><SlidersHorizontal size={17}/> Search</button>
      </div>
      <div className="results-head"><b>{jobs.length} opportunities</b><span className="muted">Newest first</span></div>
      <div className="job-list">{jobs.map(j=><JobCard key={j._id} job={j}/>)}</div>
      {!jobs.length && <div className="empty">No jobs found. Try another search.</div>}
    </div>
  );
}
