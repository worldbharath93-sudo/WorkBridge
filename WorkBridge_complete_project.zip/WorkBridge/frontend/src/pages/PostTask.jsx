import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";

export default function PostTask() {
  const nav=useNavigate();
  const [form,setForm]=useState({title:"",description:"",skills:"",budgetMin:"",budgetMax:"",duration:"2 Days",location:"Remote / India",category:"Development"});
  const [error,setError]=useState("");

  const submit=async e=>{
    e.preventDefault(); setError("");
    try{
      const r=await api.createJob(form);
      nav(`/jobs/${r.job._id}`);
    }catch(err){setError(err.message);}
  };

  return <div className="page narrow">
    <div className="page-title"><p className="eyebrow">BUSINESS</p><h1>Post a Task</h1><p className="muted">Describe the short-term work and find suitable talent.</p></div>
    {error&&<div className="alert error">{error}</div>}
    <form className="card form-card" onSubmit={submit}>
      <label>Task title</label><input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Website landing page design"/>
      <label>Description</label><textarea required rows="5" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Explain the task, expected output and requirements"/>
      <div className="form-grid">
        <div><label>Skills</label><input required value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})} placeholder="React, CSS, Figma"/></div>
        <div><label>Category</label><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Development</option><option>Design</option><option>Marketing</option><option>Admin</option><option>Writing</option></select></div>
        <div><label>Minimum budget (₹)</label><input type="number" required value={form.budgetMin} onChange={e=>setForm({...form,budgetMin:e.target.value})}/></div>
        <div><label>Maximum budget (₹)</label><input type="number" required value={form.budgetMax} onChange={e=>setForm({...form,budgetMax:e.target.value})}/></div>
        <div><label>Duration</label><select value={form.duration} onChange={e=>setForm({...form,duration:e.target.value})}><option>1 Day</option><option>2 Days</option><option>3 Days</option><option>5 Days</option><option>1 Week</option><option>2 Weeks</option></select></div>
        <div><label>Location</label><input value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></div>
      </div>
      <button className="btn primary">Publish Task</button>
    </form>
  </div>;
}
