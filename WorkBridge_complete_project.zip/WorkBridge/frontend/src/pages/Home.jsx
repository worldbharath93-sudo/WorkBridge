import React, { useEffect, useState } from "react";
import { ArrowRight, BriefcaseBusiness, CircleDollarSign, Clock3, Crosshair, Search, Sparkles, Target, UserRound } from "lucide-react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../App";
import JobCard from "../components/JobCard";

export default function Home() {
  const { user } = useAuth();
  const [jobs, setJobs] = useState([]);

  useEffect(() => { api.jobs().then(r=>setJobs(r.jobs.slice(0,4))).catch(()=>{}); }, []);

  return (
    <div className="page">
      <section className="hero">
        <div>
          <p className="eyebrow">YOUR SKILLS. YOUR OPPORTUNITIES.</p>
          <h1>Find work that fits<br/><span>what you can do.</span></h1>
          <p>Discover short-term tasks, connect with businesses, earn fairly, and build verified practical experience.</p>
          <div className="hero-actions">
            <Link className="btn primary" to="/jobs">Find Jobs <ArrowRight size={17}/></Link>
            {user.role === "business" && <Link className="btn outline" to="/post-task">Post a Task</Link>}
          </div>
        </div>
        <div className="hero-art">
          <div className="hero-circle">💼</div>
          <div className="float-card fc1"><BriefcaseBusiness size={18}/> Flexible work</div>
          <div className="float-card fc2"><CircleDollarSign size={18}/> Fair pay</div>
          <div className="float-card fc3"><Sparkles size={18}/> New skills</div>
        </div>
      </section>

      <section className="quick-grid">
        <Link to="/jobs" className="quick-card pink"><Search/><h3>Find Jobs</h3><p>Explore short-term and project-based work.</p></Link>
        {user.role === "business" ? <Link to="/post-task" className="quick-card blue"><BriefcaseBusiness/><h3>Post a Task</h3><p>Hire students and skilled professionals.</p></Link> : <Link to="/profile" className="quick-card blue"><UserRound/><h3>My Profile</h3><p>Show your skills and previous experience.</p></Link>}
        <Link to="/profile" className="quick-card green"><Target/><h3>Build Skills</h3><p>Track completed work and verified skills.</p></Link>
        <Link to="/jobs" className="quick-card orange"><CircleDollarSign/><h3>Fair Pay</h3><p>See a recommended range for each task.</p></Link>
      </section>

      <section className="section-head"><div><p className="eyebrow">OPPORTUNITIES</p><h2>Featured jobs & tasks</h2></div><Link to="/jobs">View all <ArrowRight size={16}/></Link></section>
      <div className="job-grid">{jobs.map(j=><JobCard key={j._id} job={j}/>)}</div>

      <section className="benefits">
        <div><span className="benefit-icon"><CircleDollarSign/></span><h3>Fair Pay</h3><p>Understand a suggested payment range for the work.</p></div>
        <div><span className="benefit-icon"><Sparkles/></span><h3>Skill Growth</h3><p>Build a practical record of your completed tasks.</p></div>
        <div><span className="benefit-icon"><Crosshair/></span><h3>Smart Matching</h3><p>Compare your skills and availability with task needs.</p></div>
        <div><span className="benefit-icon"><Clock3/></span><h3>Flexible Work</h3><p>Find short-duration and location-friendly opportunities.</p></div>
      </section>
    </div>
  );
}
