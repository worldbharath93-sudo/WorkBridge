import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BriefcaseBusiness, LockKeyhole, Mail, Users } from "lucide-react";
import { useAuth } from "../App";

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const submit = async e => {
    e.preventDefault();
    setError("");
    try { await login(form); nav("/"); }
    catch (err) { setError(err.message); }
  };

  return (
    <div className="auth-page">
      <div className="auth-visual">
        <div className="visual-logo"><BriefcaseBusiness size={30}/><b>WorkBridge</b></div>
        <div className="visual-copy">
          <p className="eyebrow">CONNECT • WORK • GROW</p>
          <h1>Small tasks.<br/>Big opportunities.</h1>
          <p>Find flexible work, discover skilled people, and turn practical skills into real experience.</p>
        </div>
        <div className="people-art">
          <div className="person person-one">👨‍💻</div>
          <div className="person person-two">👩‍💼</div>
          <div className="store">🏪</div>
        </div>
      </div>

      <div className="auth-card-wrap">
        <form className="auth-card" onSubmit={submit}>
          <div className="center">
            <div className="auth-icon"><Users size={25}/></div>
            <h2>Welcome back</h2>
            <p className="muted">Log in to continue to your account</p>
          </div>
          {error && <div className="alert error">{error}</div>}
          <label>Email or Username</label>
          <div className="input-icon"><Mail size={17}/><input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" /></div>
          <label>Password</label>
          <div className="input-icon"><LockKeyhole size={17}/><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="••••••••" /></div>
          <button className="btn primary full">Log In</button>
          <div className="or"><span>OR</span></div>
          <button type="button" className="btn outline full">Continue with Google</button>
          <p className="auth-bottom">Don't have an account? <Link to="/register">Sign up</Link></p>
          <p className="demo-note">Demo after seeding: worker@example.com / password123</p>
        </form>
      </div>
    </div>
  );
}
