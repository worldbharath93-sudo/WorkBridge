import React, { useEffect, useState } from "react";
import { ArrowLeft, CheckCircle2, Clock3, MapPin, Wallet } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../App";

export default function JobDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const [job,setJob]=useState(null), [match,setMatch]=useState(null), [pay,setPay]=useState(null), [message,setMessage]=useState("");

  useEffect(() => {
    api.job(id).then(r=>setJob(r.job));
    api.fairPay(id).then(setPay);
    if(user.role==="worker") api.match(id).then(setMatch);
  }, [id]);

  if(!job) return <div className="loading">Loading job...</div>;

  const apply = async () => {
    try { await api.apply(id); setMessage("Application submitted successfully."); }
    catch(e){ setMessage(e.message); }
  };

  return (
    <div className="page">
      <Link className="back" to="/jobs"><ArrowLeft size={16}/> Back to jobs</Link>
      <div className="detail-layout">
        <section className="detail-main card">
          <span className="category">{job.category}</span>
          <h1>{job.title}</h1>
          <div className="job-meta large">
            <span><Wallet/> ₹{job.budgetMin} – ₹{job.budgetMax}</span>
            <span><Clock3/> {job.duration}</span>
            <span><MapPin/> {job.location}</span>
          </div>
          <hr/>
          <h2>About this task</h2>
          <p>{job.description}</p>
          <h2>Required skills</h2>
          <div className="chips">{job.skills.map(s=><span className="chip" key={s}>{s}</span>)}</div>
          {user.role==="worker" && <button className="btn primary wide" onClick={apply}>Apply Now</button>}
          {message && <div className="alert success">{message}</div>}
        </section>

        <aside className="detail-side">
          <div className="card">
            <h3>Fair pay estimate</h3>
            {pay && <><div className="pay-number">₹{pay.recommendedMin} – ₹{pay.recommendedMax}</div><p className="muted">{pay.basis}</p></>}
          </div>
          {match && <div className="card match-card"><h3>Your match</h3><div className="score">{match.score}%</div><p>{match.explanation}</p><div className="matched">{match.matchedSkills.map(s=><span key={s}><CheckCircle2 size={15}/> {s}</span>)}</div></div>}
          <div className="card"><h3>Business</h3><p><b>{job.employer?.name}</b></p><p className="muted">{job.employer?.location}</p></div>
        </aside>
      </div>
    </div>
  );
}
