import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BriefcaseBusiness } from "lucide-react";
import { useAuth } from "../App";

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ name:"", email:"", password:"", role:"worker", location:"", skills:"", bio:"" });
  const [error, setError] = useState("");

  const submit = async e => {
    e.preventDefault(); setError("");
    try {
      await register({
        ...form,
        skills: form.skills.split(",").map(s=>s.trim()).filter(Boolean)
      });
      nav("/");
    } catch (err) { setError(err.message); }
  };

  return (
    <div className="auth-page simple-auth">
      <div className="auth-card register-card">
        <div className="center">
          <div className="brand big"><span className="brand-mark"><BriefcaseBusiness size={23}/></span> WorkBridge</div>
          <h2>Create your account</h2>
          <p className="muted">Join the flexible work community</p>
        </div>
        {error && <div className="alert error">{error}</div>}
        <div className="form-grid">
          <div><label>Full name</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
          <div><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div>
          <div><label>Password</label><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></div>
          <div><label>Role</label><select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="worker">Student / Worker</option><option value="business">Small Business</option></select></div>
          <div><label>Location</label><input value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="City, India"/></div>
          <div><label>Availability</label><select value={form.availability || "Flexible"} onChange={e=>setForm({...form,availability:e.target.value})}><option>Flexible</option><option>Weekdays</option><option>Weekends</option></select></div>
          <div className="full-col"><label>Skills (comma separated)</label><input value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})} placeholder="Python, React, Excel"/></div>
          <div className="full-col"><label>Short bio</label><textarea value={form.bio} onChange={e=>setForm({...form,bio:e.target.value})} rows="3"/></div>
        </div>
        <button className="btn primary full" onClick={submit}>Create Account</button>
        <p className="auth-bottom">Already have an account? <Link to="/login">Log in</Link></p>
      </div>
    </div>
  );
}
