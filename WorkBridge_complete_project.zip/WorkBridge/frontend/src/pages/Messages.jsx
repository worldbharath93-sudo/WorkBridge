import React, { useEffect, useState } from "react";
import { MessageCircle, Send } from "lucide-react";
import { api } from "../api";
import { useAuth } from "../App";

export default function Messages() {
  const { user }=useAuth();
  const [messages,setMessages]=useState([]);
  const [receiver,setReceiver]=useState("");
  const [text,setText]=useState("");
  const [error,setError]=useState("");

  const load=()=>api.messages().then(r=>setMessages(r.messages)).catch(()=>{});
  useEffect(load,[]);

  const send=async e=>{
    e.preventDefault(); setError("");
    try{await api.sendMessage({receiverId:receiver,text});setText("");load();}
    catch(err){setError(err.message);}
  };

  return <div className="page">
    <div className="page-title"><p className="eyebrow">COMMUNICATION</p><h1>Messages</h1><p className="muted">Talk with businesses and workers about opportunities.</p></div>
    <div className="message-layout">
      <section className="card message-list">
        {!messages.length&&<div className="empty">No messages yet.</div>}
        {messages.map(m=><div className={`message ${m.senderId===user.id?"mine":""}`} key={m._id}><MessageCircle size={17}/><div><b>{m.senderId===user.id?"You":"Contact"}</b><p>{m.text}</p></div></div>)}
      </section>
      <form className="card message-form" onSubmit={send}>
        <h3>New message</h3>
        {error&&<div className="alert error">{error}</div>}
        <label>Receiver user ID</label><input value={receiver} onChange={e=>setReceiver(e.target.value)} placeholder="Paste a user's ID"/>
        <label>Message</label><textarea rows="8" value={text} onChange={e=>setText(e.target.value)} placeholder="Write your message..."/>
        <button className="btn primary"><Send size={17}/> Send</button>
      </form>
    </div>
  </div>;
}
