const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

async function request(path, options = {}) {
  const token = localStorage.getItem("token");
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  login: (body) => request("/auth/login", { method: "POST", body: JSON.stringify(body) }),
  register: (body) => request("/auth/register", { method: "POST", body: JSON.stringify(body) }),
  me: () => request("/me"),
  updateMe: (body) => request("/me", { method: "PUT", body: JSON.stringify(body) }),
  jobs: (params = "") => request(`/jobs${params}`),
  job: (id) => request(`/jobs/${id}`),
  createJob: (body) => request("/jobs", { method: "POST", body: JSON.stringify(body) }),
  match: (id) => request(`/jobs/${id}/match`),
  fairPay: (id) => request(`/jobs/${id}/fair-pay`),
  apply: (id) => request(`/jobs/${id}/apply`, { method: "POST" }),
  applications: () => request("/my/applications"),
  myJobs: () => request("/my/jobs"),
  messages: () => request("/messages"),
  sendMessage: (body) => request("/messages", { method: "POST", body: JSON.stringify(body) }),
  seed: () => request("/seed", { method: "POST" })
};
