import React, { createContext, useContext, useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { api } from "./api";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Home from "./pages/Home";
import Jobs from "./pages/Jobs";
import JobDetails from "./pages/JobDetails";
import PostTask from "./pages/PostTask";
import Profile from "./pages/Profile";
import Messages from "./pages/Messages";

const AuthContext = createContext(null);

export function useAuth() {
  return useContext(AuthContext);
}

function Private({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading">Loading...</div>;
  return user ? children : <Navigate to="/login" replace />;
}

function Layout({ children }) {
  return <>
    <Navbar />
    <main>{children}</main>
  </>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!localStorage.getItem("token")) {
      setLoading(false);
      return;
    }
    api.me()
      .then(r => setUser(r.user))
      .catch(() => localStorage.removeItem("token"))
      .finally(() => setLoading(false));
  }, []);

  const login = async (body) => {
    const r = await api.login(body);
    localStorage.setItem("token", r.token);
    setUser(r.user);
    return r;
  };

  const register = async (body) => {
    const r = await api.register(body);
    localStorage.setItem("token", r.token);
    setUser(r.user);
    return r;
  };

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
        <Route path="/register" element={user ? <Navigate to="/" /> : <Register />} />
        <Route path="/" element={<Private><Layout><Home /></Layout></Private>} />
        <Route path="/jobs" element={<Private><Layout><Jobs /></Layout></Private>} />
        <Route path="/jobs/:id" element={<Private><Layout><JobDetails /></Layout></Private>} />
        <Route path="/post-task" element={<Private><Layout><PostTask /></Layout></Private>} />
        <Route path="/profile" element={<Private><Layout><Profile /></Layout></Private>} />
        <Route path="/messages" element={<Private><Layout><Messages /></Layout></Private>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </AuthContext.Provider>
  );
}
