# WorkBridge — Short-Term Work & Skill Platform

A full-stack college project based on the supplied project document. It connects small businesses with students/skilled workers for short-term, project-based work and includes:
- User registration/login
- Worker and business roles
- Job/task posting
- Job browsing and filtering
- Apply to jobs
- Smart matching score
- Fair-pay estimate
- Completed-task / skill profile
- Messaging UI/API
- MongoDB persistence

The project document describes matching using skills, availability, location, task requirements, budget and duration, plus fair-pay and skill-growth/work-verification features.

## Stack
Frontend: React + Vite + React Router
Backend: Flask + Flask-CORS + PyMongo + JWT
Database: MongoDB Atlas or local MongoDB

## 1. Backend setup
```bash
cd backend
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
# source venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set:
- MONGO_URI
- JWT_SECRET

Run:
```bash
python app.py
```
Backend: http://localhost:5000

## 2. Frontend setup
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

The frontend expects the backend at:
`http://localhost:5000/api`

You can change it in `frontend/.env`.

## Demo flow
1. Register a worker account.
2. Register a business account in a second browser/incognito window.
3. Business posts a task.
4. Worker browses jobs and applies.
5. Open a job to see matching and fair-pay information.
6. Update worker skills/profile.
7. Use Messages to demonstrate communication.

## Production deployment
Frontend can be deployed to Vercel/Netlify.
Backend can be deployed to Render/Railway.
Use MongoDB Atlas for the database.
Set the frontend API URL to the deployed backend URL.
