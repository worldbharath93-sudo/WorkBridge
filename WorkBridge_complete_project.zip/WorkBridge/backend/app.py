import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from bson import ObjectId
from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()

app = Flask(__name__)
CORS(app)

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "workbridge")
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
users = db.users
jobs = db.jobs
applications = db.applications
messages = db.messages

def clean(doc):
    if not doc:
        return None
    doc["_id"] = str(doc["_id"])
    return doc

def token_for(user):
    payload = {
        "sub": str(user["_id"]),
        "email": user["email"],
        "role": user["role"],
        "exp": datetime.now(timezone.utc) + timedelta(days=2),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def current_user():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(header.split(" ", 1)[1], JWT_SECRET, algorithms=["HS256"])
        return users.find_one({"_id": ObjectId(payload["sub"])})
    except Exception:
        return None

def auth_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user:
            return jsonify({"error": "Authentication required"}), 401
        return fn(user, *args, **kwargs)
    return wrapper

def user_public(user):
    return {
        "id": str(user["_id"]),
        "name": user.get("name", ""),
        "email": user.get("email", ""),
        "role": user.get("role", "worker"),
        "location": user.get("location", ""),
        "bio": user.get("bio", ""),
        "skills": user.get("skills", []),
        "availability": user.get("availability", "Flexible"),
        "experience": user.get("experience", []),
        "completedTasks": user.get("completedTasks", 0),
        "verifiedSkills": user.get("verifiedSkills", []),
    }

def normalize_job(job):
    j = clean(job)
    if j.get("employerId"):
        j["employerId"] = str(j["employerId"])
    return j

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "WorkBridge API"})

@app.post("/api/auth/register")
def register():
    data = request.get_json() or {}
    required = ["name", "email", "password", "role"]
    if any(not data.get(k) for k in required):
        return jsonify({"error": "Name, email, password and role are required"}), 400

    role = data["role"].lower()
    if role not in ["worker", "business"]:
        return jsonify({"error": "Role must be worker or business"}), 400

    email = data["email"].strip().lower()
    if users.find_one({"email": email}):
        return jsonify({"error": "Email already registered"}), 409

    user = {
        "name": data["name"].strip(),
        "email": email,
        "password": generate_password_hash(data["password"]),
        "role": role,
        "location": data.get("location", ""),
        "bio": data.get("bio", ""),
        "skills": data.get("skills", []),
        "availability": data.get("availability", "Flexible"),
        "experience": [],
        "completedTasks": 0,
        "verifiedSkills": [],
        "createdAt": datetime.now(timezone.utc),
    }
    result = users.insert_one(user)
    user["_id"] = result.inserted_id
    return jsonify({"token": token_for(user), "user": user_public(user)}), 201

@app.post("/api/auth/login")
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    user = users.find_one({"email": email})

    if not user or not check_password_hash(user["password"], password):
        return jsonify({"error": "Invalid email or password"}), 401

    return jsonify({"token": token_for(user), "user": user_public(user)})

@app.get("/api/me")
@auth_required
def me(user):
    return jsonify({"user": user_public(user)})

@app.put("/api/me")
@auth_required
def update_me(user):
    data = request.get_json() or {}
    allowed = ["name", "location", "bio", "skills", "availability"]
    update = {k: data[k] for k in allowed if k in data}
    if "skills" in update and isinstance(update["skills"], str):
        update["skills"] = [x.strip() for x in update["skills"].split(",") if x.strip()]
    users.update_one({"_id": user["_id"]}, {"$set": update})
    updated = users.find_one({"_id": user["_id"]})
    return jsonify({"user": user_public(updated)})

@app.get("/api/jobs")
def list_jobs():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    location = request.args.get("location", "").strip()

    query = {}
    if q:
        query["$or"] = [
            {"title": {"$regex": q, "$options": "i"}},
            {"description": {"$regex": q, "$options": "i"}},
            {"skills": {"$regex": q, "$options": "i"}},
        ]
    if category:
        query["category"] = {"$regex": category, "$options": "i"}
    if location:
        query["location"] = {"$regex": location, "$options": "i"}

    result = jobs.find(query).sort("createdAt", -1)
    return jsonify({"jobs": [normalize_job(x) for x in result]})

@app.get("/api/jobs/<job_id>")
def get_job(job_id):
    try:
        job = jobs.find_one({"_id": ObjectId(job_id)})
    except Exception:
        return jsonify({"error": "Invalid job id"}), 400
    if not job:
        return jsonify({"error": "Job not found"}), 404

    employer = users.find_one({"_id": job["employerId"]})
    data = normalize_job(job)
    data["employer"] = {
        "name": employer.get("name", "Business") if employer else "Business",
        "location": employer.get("location", "") if employer else "",
    }
    return jsonify({"job": data})

@app.post("/api/jobs")
@auth_required
def create_job(user):
    if user.get("role") != "business":
        return jsonify({"error": "Only business accounts can post tasks"}), 403

    data = request.get_json() or {}
    required = ["title", "description", "skills", "budgetMin", "budgetMax", "duration", "location", "category"]
    if any(k not in data or data[k] in ["", None] for k in required):
        return jsonify({"error": "Please fill all task fields"}), 400

    skills = data["skills"]
    if isinstance(skills, str):
        skills = [x.strip() for x in skills.split(",") if x.strip()]

    job = {
        "title": data["title"].strip(),
        "description": data["description"].strip(),
        "skills": skills,
        "budgetMin": float(data["budgetMin"]),
        "budgetMax": float(data["budgetMax"]),
        "duration": data["duration"],
        "location": data["location"],
        "category": data["category"],
        "status": "open",
        "employerId": user["_id"],
        "createdAt": datetime.now(timezone.utc),
        "applicants": 0,
    }
    result = jobs.insert_one(job)
    job["_id"] = result.inserted_id
    return jsonify({"job": normalize_job(job)}), 201

@app.get("/api/jobs/<job_id>/match")
@auth_required
def match_job(user, job_id):
    try:
        job = jobs.find_one({"_id": ObjectId(job_id)})
    except Exception:
        return jsonify({"error": "Invalid job id"}), 400
    if not job:
        return jsonify({"error": "Job not found"}), 404

    worker_skills = {str(s).lower() for s in user.get("skills", [])}
    job_skills = {str(s).lower() for s in job.get("skills", [])}
    overlap = worker_skills.intersection(job_skills)
    skill_score = (len(overlap) / max(len(job_skills), 1)) * 70

    location_score = 15 if (
        not job.get("location") or
        not user.get("location") or
        job["location"].lower() in user["location"].lower() or
        user["location"].lower() in job["location"].lower()
    ) else 0

    availability_score = 15 if user.get("availability") in ["Flexible", job.get("duration")] else 8
    score = round(min(100, skill_score + location_score + availability_score))

    return jsonify({
        "score": score,
        "matchedSkills": sorted(overlap),
        "explanation": "Score combines skill overlap, location compatibility and availability."
    })

@app.get("/api/jobs/<job_id>/fair-pay")
def fair_pay(job_id):
    try:
        job = jobs.find_one({"_id": ObjectId(job_id)})
    except Exception:
        return jsonify({"error": "Invalid job id"}), 400
    if not job:
        return jsonify({"error": "Job not found"}), 404

    low = float(job["budgetMin"])
    high = float(job["budgetMax"])
    midpoint = round((low + high) / 2)
    return jsonify({
        "recommendedMin": round(low),
        "recommendedMax": round(high),
        "midpoint": midpoint,
        "basis": "Illustrative estimate based on the task budget, required skills and duration supplied by the business."
    })

@app.post("/api/jobs/<job_id>/apply")
@auth_required
def apply_job(user, job_id):
    if user.get("role") != "worker":
        return jsonify({"error": "Only workers can apply"}), 403
    try:
        oid = ObjectId(job_id)
    except Exception:
        return jsonify({"error": "Invalid job id"}), 400

    job = jobs.find_one({"_id": oid})
    if not job:
        return jsonify({"error": "Job not found"}), 404

    if applications.find_one({"jobId": oid, "workerId": user["_id"]}):
        return jsonify({"error": "You already applied"}), 409

    app_doc = {
        "jobId": oid,
        "workerId": user["_id"],
        "status": "applied",
        "createdAt": datetime.now(timezone.utc),
    }
    applications.insert_one(app_doc)
    jobs.update_one({"_id": oid}, {"$inc": {"applicants": 1}})
    return jsonify({"message": "Application submitted"})

@app.get("/api/my/applications")
@auth_required
def my_applications(user):
    docs = applications.find({"workerId": user["_id"]}).sort("createdAt", -1)
    output = []
    for a in docs:
        job = jobs.find_one({"_id": a["jobId"]})
        if job:
            item = normalize_job(job)
            item["applicationStatus"] = a["status"]
            output.append(item)
    return jsonify({"applications": output})

@app.get("/api/my/jobs")
@auth_required
def my_jobs(user):
    docs = jobs.find({"employerId": user["_id"]}).sort("createdAt", -1)
    return jsonify({"jobs": [normalize_job(x) for x in docs]})

@app.get("/api/messages")
@auth_required
def get_messages(user):
    docs = messages.find({
        "$or": [{"senderId": user["_id"]}, {"receiverId": user["_id"]}]
    }).sort("createdAt", -1).limit(100)

    output = []
    for m in docs:
        item = clean(m)
        item["senderId"] = str(item["senderId"])
        item["receiverId"] = str(item["receiverId"])
        output.append(item)
    return jsonify({"messages": output})

@app.post("/api/messages")
@auth_required
def send_message(user):
    data = request.get_json() or {}
    if not data.get("receiverId") or not data.get("text"):
        return jsonify({"error": "Receiver and message are required"}), 400
    try:
        receiver = ObjectId(data["receiverId"])
    except Exception:
        return jsonify({"error": "Invalid receiver"}), 400

    if not users.find_one({"_id": receiver}):
        return jsonify({"error": "Receiver not found"}), 404

    msg = {
        "senderId": user["_id"],
        "receiverId": receiver,
        "text": data["text"].strip(),
        "createdAt": datetime.now(timezone.utc),
    }
    messages.insert_one(msg)
    return jsonify({"message": "Message sent"}), 201

@app.post("/api/seed")
def seed():
    if users.count_documents({}) > 0 or jobs.count_documents({}) > 0:
        return jsonify({"message": "Database already has data"})

    business = {
        "name": "GreenTech Solutions",
        "email": "business@example.com",
        "password": generate_password_hash("password123"),
        "role": "business",
        "location": "Hyderabad, India",
        "bio": "Small business looking for flexible digital talent.",
        "skills": [],
        "availability": "Flexible",
        "experience": [],
        "completedTasks": 0,
        "verifiedSkills": [],
    }
    worker = {
        "name": "Demo Worker",
        "email": "worker@example.com",
        "password": generate_password_hash("password123"),
        "role": "worker",
        "location": "India",
        "bio": "Student and junior developer interested in short-term projects.",
        "skills": ["Python", "React", "HTML", "CSS", "Data Entry"],
        "availability": "Flexible",
        "experience": [],
        "completedTasks": 5,
        "verifiedSkills": ["Python", "HTML"],
    }
    b_id = users.insert_one(business).inserted_id
    w_id = users.insert_one(worker).inserted_id

    demo_jobs = [
        {
            "title": "Website UI Design",
            "description": "Design a clean responsive landing page for a small business.",
            "skills": ["Figma", "UI Design", "HTML"],
            "budgetMin": 2000, "budgetMax": 4000,
            "duration": "2 Days", "location": "Remote / India", "category": "Design",
            "status": "open", "employerId": b_id, "applicants": 3,
            "createdAt": datetime.now(timezone.utc)
        },
        {
            "title": "Data Entry Work",
            "description": "Enter product details into an existing spreadsheet and verify records.",
            "skills": ["Excel", "Data Entry"],
            "budgetMin": 800, "budgetMax": 1500,
            "duration": "3 Days", "location": "Remote / India", "category": "Admin",
            "status": "open", "employerId": b_id, "applicants": 6,
            "createdAt": datetime.now(timezone.utc)
        },
        {
            "title": "Social Media Content",
            "description": "Create short promotional posts for a new product campaign.",
            "skills": ["Content Writing", "Social Media"],
            "budgetMin": 1500, "budgetMax": 3000,
            "duration": "5 Days", "location": "Remote / India", "category": "Marketing",
            "status": "open", "employerId": b_id, "applicants": 4,
            "createdAt": datetime.now(timezone.utc)
        },
    ]
    jobs.insert_many(demo_jobs)
    return jsonify({
        "message": "Demo data created",
        "worker": {"email": "worker@example.com", "password": "password123"},
        "business": {"email": "business@example.com", "password": "password123"}
    })

if __name__ == "__main__":
    app.run(debug=True, port=5000)
