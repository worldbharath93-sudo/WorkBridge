"""Run the API first, then call POST /api/seed from Postman or: curl -X POST http://localhost:5000/api/seed"""
